// Reserved for future enhancements (infinite scroll, etc.)
