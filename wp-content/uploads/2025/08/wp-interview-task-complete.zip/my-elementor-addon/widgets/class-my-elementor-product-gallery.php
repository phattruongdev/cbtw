<?php
namespace MyElAddon;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if (!defined('ABSPATH')) exit;

class Product_Gallery extends Widget_Base {
  public function get_name(){ return 'myel-product-gallery'; }
  public function get_title(){ return __('Product Gallery (DummyJSON)', 'my-el-addon'); }
  public function get_icon(){ return 'eicon-gallery-grid'; }
  public function get_categories(){ return ['general']; }

  protected function register_controls(){
    $this->start_controls_section('content', [
      'label' => __('Content', 'my-el-addon'),
    ]);

    $this->add_control('category', [
      'label' => __('Category (optional)', 'my-el-addon'),
      'type' => Controls_Manager::TEXT,
      'placeholder' => 'smartphones, laptops, ...',
    ]);

    $this->add_control('limit', [
      'label' => __('Limit', 'my-el-addon'),
      'type' => Controls_Manager::NUMBER,
      'min' => 1,
      'max' => 50,
      'default' => 12,
    ]);

    $this->add_control('columns', [
      'label' => __('Columns (desktop)', 'my-el-addon'),
      'type' => Controls_Manager::NUMBER,
      'min' => 1,
      'max' => 6,
      'default' => 4,
    ]);

    $this->end_controls_section();

    $this->start_controls_section('interactions', [
      'label' => __('Interactions', 'my-el-addon'),
    ]);

    $this->add_control('show_sort', [
      'label' => __('Show Sort Controls', 'my-el-addon'),
      'type' => Controls_Manager::SWITCHER,
      'default' => 'yes',
    ]);

    $this->end_controls_section();
  }

  protected function render(){
    $settings = $this->get_settings_for_display();
    $category = sanitize_text_field($settings['category'] ?? '');
    $limit    = intval($settings['limit'] ?? 12);
    $columns  = max(1, min(6, intval($settings['columns'] ?? 4)));
    $show_sort= ($settings['show_sort'] === 'yes');

    $wrapper_id = 'pg_'.uniqid();
    ?>
    <div id="<?php echo esc_attr($wrapper_id); ?>" class="myel-product-gallery" style="--cols: <?php echo esc_attr(12 / max(1,$columns)); ?>;">
      <?php if ($show_sort): ?>
      <div class="card" style="margin-bottom: .75rem; display:flex; gap:.5rem; align-items:center;">
        <label><?php esc_html_e('Sort by', 'my-el-addon'); ?></label>
        <select class="myel-sort">
          <option value="title">Title</option>
          <option value="price">Price</option>
        </select>
        <select class="myel-order">
          <option value="asc">ASC</option>
          <option value="desc">DESC</option>
        </select>
      </div>
      <?php endif; ?>

      <div class="grid myel-grid">
        <div class="myel-loading">Loading…</div>
      </div>
    </div>
    <script>
      (function($){
        const root   = $('#<?php echo esc_js($wrapper_id); ?>');
        const grid   = root.find('.myel-grid');
        const sortEl = root.find('.myel-sort');
        const ordEl  = root.find('.myel-order');

        function load(){
          grid.html('<div class="myel-loading">Loading…</div>');
          $.post(MYEL.ajaxurl, {
            action: 'myel_products',
            nonce: MYEL.nonce,
            category: <?php echo wp_json_encode($category); ?>,
            limit: <?php echo wp_json_encode($limit); ?>,
            sort: sortEl.val() || 'title',
            order: ordEl.val() || 'asc'
          }).done(function(res){
            if (res && res.success){
              grid.html(res.data.html);
            } else {
              grid.html('<p>Failed to load.</p>');
            }
          }).fail(function(){
            grid.html('<p>API error.</p>');
          });
        }

        root.on('change', '.myel-sort, .myel-order', load);
        load();
      })(jQuery);
    </script>
    <?php
  }
}
