<?php
/**
 * Plugin Name: My Elementor Addon (Interview Task)
 * Description: Adds a Product Gallery widget powered by DummyJSON with AJAX filtering/sorting.
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: my-el-addon
 */
if (!defined('ABSPATH')) exit;

// === Define ===
define('MY_EL_ADDON_PATH', plugin_dir_path(__FILE__));
define('MY_EL_ADDON_URL', plugin_dir_url(__FILE__));

// === Enqueue front assets ===
add_action('wp_enqueue_scripts', function(){
  wp_enqueue_script('my-el-addon-front', MY_EL_ADDON_URL.'public/front.js', ['jquery'], '1.0.0', true);
  wp_localize_script('my-el-addon-front', 'MYEL', [
    'ajaxurl' => admin_url('admin-ajax.php'),
    'nonce'   => wp_create_nonce('myel_nonce')
  ]);
  wp_enqueue_style('my-el-addon-style', MY_EL_ADDON_URL.'public/front.css', [], '1.0.0');
});

// === Elementor widget register ===
add_action('elementor/widgets/register', function($widgets_manager){
  require_once MY_EL_ADDON_PATH.'widgets/class-my-elementor-product-gallery.php';
  $widgets_manager->register(new \MyElAddon\Product_Gallery());
});

// === AJAX: filter/sort products ===
add_action('wp_ajax_myel_products', 'myel_products_ajax');
add_action('wp_ajax_nopriv_myel_products', 'myel_products_ajax');

function myel_products_ajax(){
  check_ajax_referer('myel_nonce', 'nonce');

  $category = isset($_POST['category']) ? sanitize_text_field(wp_unslash($_POST['category'])) : '';
  $limit    = isset($_POST['limit']) ? max(1, min(50, intval($_POST['limit']))) : 12;
  $sort     = isset($_POST['sort']) ? sanitize_text_field(wp_unslash($_POST['sort'])) : 'title';
  $order    = strtolower(isset($_POST['order']) ? sanitize_text_field(wp_unslash($_POST['order'])) : 'asc');

  // Fetch data
  $endpoint = $category ? 'products/category/'.rawurlencode($category) : 'products?limit='.$limit;
  $res = wp_remote_get('https://dummyjson.com/'.$endpoint, ['timeout'=>8]);
  if (is_wp_error($res)) wp_send_json_error(['message'=>'API error'], 500);
  $code = wp_remote_retrieve_response_code($res);
  if ($code !== 200) wp_send_json_error(['message'=>'Bad response'], $code);
  $data = json_decode(wp_remote_retrieve_body($res), true);
  $products = $data['products'] ?? [];

  // Sort in PHP (title|price)
  usort($products, function($a, $b) use ($sort, $order){
    $va = $a[$sort] ?? '';
    $vb = $b[$sort] ?? '';
    if ($va == $vb) return 0;
    $cmp = ($va < $vb) ? -1 : 1;
    return ($order === 'desc') ? -$cmp : $cmp;
  });

  // Slice to limit
  $products = array_slice($products, 0, $limit);

  // Return HTML cards (simpler for Elementor)
  ob_start();
  foreach ($products as $p){
    $id    = intval($p['id'] ?? 0);
    $thumb = esc_url($p['thumbnail'] ?? '');
    $title = esc_html($p['title'] ?? '');
    $price = esc_html($p['price'] ?? '');
    $cat   = esc_html($p['category'] ?? '');
    $link  = esc_url(home_url('/product/'.$id));
    echo '<div class="card" style="grid-column: span var(--cols, 3);">';
    echo '<img class="img-fluid" src="'.$thumb.'" alt="'.$title.'">';
    echo '<h3 style="font-size:1rem;margin:.5rem 0;">'.$title.'</h3>';
    echo '<p class="price">$'.$price.'</p>';
    echo '<span class="badge">'.$cat.'</span><br />';
    echo '<a class="btn" href="'.$link.'">View Details</a>';
    echo '</div>';
  }
  $html = ob_get_clean();

  wp_send_json_success(['html'=>$html]);
}
