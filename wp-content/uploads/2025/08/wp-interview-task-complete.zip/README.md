# WordPress Interview Task – Custom Theme + Elementor Product Gallery

## Description
- Theme **my-custom-theme** with dynamic `/product/{id}` single product page (DummyJSON data).
- Plugin **my-elementor-addon** adding a Product Gallery widget with AJAX sort/order.

## Requirements
- WordPress latest, PHP 7.4+, Elementor (free).

## Setup
1. Copy `my-custom-theme/` to `wp-content/themes/`
2. Copy `my-elementor-addon/` to `wp-content/plugins/`
3. Activate both in WP Admin.
4. Go to **Settings → Permalinks** and click **Save** (flush rewrites).
5. Create a Home page with Elementor and add **Product Gallery (DummyJSON)** widget.

## Notes
- API: https://dummyjson.com/products
- Responses cached via transients in theme.
